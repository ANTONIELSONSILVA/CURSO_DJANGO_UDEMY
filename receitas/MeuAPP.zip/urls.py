"""
URL configuration for AplicacaoDjango project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.http import HttpResponse
#from receitas.views import home

from . import views

from receitas.views import home, receitas
from django.conf.urls.static import static
from django.conf import settings


"""
def my_view(resquest):
        HttpResponse.headers
        #return HttpResponse('<h1>VAi torma no cu<h1>')
        #return HttpResponse(HttpResponse.status_code)
        return HttpResponse(HttpResponse.status_code)
"""

# isso afeta a url da aplicação ficando receitas:receita ou receitas:home
app_name = 'receitas'

urlpatterns = [
    # Página HOME
    path('', home, name="home"),
    path('receitas/category/<int:category_id>/', views.category, name="category"),
    path('receitas/<int:id>/', receitas, name="receita"),
    
    
]


# para que se possa acessar um conteúdo diretamente com por exemplo um imagem
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)